<template>
    <div class="flex flex-col justify-center items-center">
        <h1 class="text-4xl font-bold mt-10">{{ title }}</h1>
        <div class="border-t border-4 border-black mt-5 w-1/16"></div>
    </div>
</template>

<script>
    export default {
        props: ['title'],
        mounted() {

        },
        methods : {

        }
    }
</script>
