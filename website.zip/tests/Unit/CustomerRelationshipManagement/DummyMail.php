<?php

namespace Tests\Unit\CustomerRelationshipManagement;

class DummyMail extends \Illuminate\Mail\Mailable
{

}
