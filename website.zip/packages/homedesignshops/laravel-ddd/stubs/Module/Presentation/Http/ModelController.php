<?php


namespace App\Module\Presentation\Http;

use Illuminate\Http\Request;

class ModelController
{
    /**
     * @param Request $request
     */
    public function index(Request $request)
    {
        // Handle the request
    }
}
