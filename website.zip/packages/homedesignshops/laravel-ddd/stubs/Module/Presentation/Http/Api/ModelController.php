<?php


namespace App\Module\Presentation\Http\Api;


use Illuminate\Http\Request;

class ModelController
{
    public function index(Request $request)
    {
        // Handle the response
    }
}
