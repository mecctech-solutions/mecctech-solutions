<?php


namespace App\Module\Application\UseCase;


final class UseCaseResult
{
    /**
     * @var int
     */
    public $id;
}
