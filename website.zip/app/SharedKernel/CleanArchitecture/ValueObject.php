<?php

namespace App\SharedKernel\CleanArchitecture;

abstract class ValueObject
{

}
