<?php

namespace App\PortfolioManagement\Infrastructure\Exceptions;

class EloquentCustomerOperationException extends \Exception
{

}
