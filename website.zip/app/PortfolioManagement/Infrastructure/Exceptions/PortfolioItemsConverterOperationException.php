<?php

namespace App\PortfolioManagement\Infrastructure\Exceptions;

class PortfolioItemsConverterOperationException extends \Exception
{

}
