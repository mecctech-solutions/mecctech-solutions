<?php


namespace App\PortfolioManagement\Application\AddPortfolioItems;


use Illuminate\Support\Collection;

final class AddPortfolioItemsResult
{

}
