<?php


namespace App\PortfolioManagement\Application\GetAllPortfolioItems;

final class GetAllPortfolioItemsInput
{

}
