<?php

namespace App\CustomerRelationshipManagement\Infrastructure\Exceptions;

class DummyCustomerRepositoryOperationException extends \Exception
{

}
