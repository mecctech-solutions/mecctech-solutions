<?php

namespace App\CustomerRelationshipManagement\Domain\Exceptions;

class CustomerNotFoundException extends \DomainException
{

}
