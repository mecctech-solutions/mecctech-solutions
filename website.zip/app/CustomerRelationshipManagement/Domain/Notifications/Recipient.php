<?php

namespace App\CustomerRelationshipManagement\Domain\Notifications;

class Recipient
{
    private string $email;

    /**
     * @param string $email
     */
    public function __construct(string $email)
    {
        $this->email = $email;
    }

    public function email(): string
    {
        return $this->email;
    }
}
