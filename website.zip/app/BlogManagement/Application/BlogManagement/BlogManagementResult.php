<?php


namespace App\BlogManagement\Application\BlogManagement;


final class BlogManagementResult
{
    /**
     * @var int
     */
    public $id;
}
