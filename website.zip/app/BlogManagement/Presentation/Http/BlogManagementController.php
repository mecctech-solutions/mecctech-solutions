<?php


namespace App\BlogManagement\Presentation\Http;

use Illuminate\Http\Request;

class BlogManagementController
{
    /**
     * @param Request $request
     */
    public function index(Request $request)
    {
        // Handle the request
    }
}
