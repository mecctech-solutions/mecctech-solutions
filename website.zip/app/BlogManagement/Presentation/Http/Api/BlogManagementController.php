<?php


namespace App\BlogManagement\Presentation\Http\Api;


use Illuminate\Http\Request;

class BlogManagementController
{
    public function index(Request $request)
    {
        // Handle the response
    }
}
