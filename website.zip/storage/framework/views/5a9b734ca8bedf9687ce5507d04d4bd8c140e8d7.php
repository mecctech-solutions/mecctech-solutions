<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>
    <?php echo e($messages); ?>

</body>
</html>
<?php /**PATH /home/fmeccanici/Documents/mecctech_solutions/website/mecctech-solutions/resources/views/emails/submit-contact-request.blade.php ENDPATH**/ ?>